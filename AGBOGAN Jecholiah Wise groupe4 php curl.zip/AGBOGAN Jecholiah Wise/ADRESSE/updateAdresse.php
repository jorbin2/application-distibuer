<?php

    require_once ('database.php');

    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');
    header('Access-Control-Allow-Methods: PUT');
    header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,
    Content-Type, Access-Control-Allow-Methods, Authorization,X-Requested-With');

    if (isset($_POST["pays"]) && isset($_POST["ville"]) && isset($_POST["rue"]) && isset($_POST["quartier"]) ){

    $pays = htmlspecialchars($_POST["pays"]);
    $ville = htmlspecialchars($_POST["ville"]);
    $rue = htmlspecialchars($_POST["rue"]);
    $quartier = htmlspecialchars($_POST["quartier"]);
    $id = $_GET['id'];

    global $conn;

    

    $sql = "UDPATE adresse SET pays =:pays, ville =:ville, rue =:rue, quartier =:quartier WHERE id =:id";
    $stmt = $conn->prepare($sql);
    $stmt -> bindParam(':pays',$pays, PDO::PARAM_STR);
    $stmt -> bindParam(':ville',$ville, PDO::PARAM_STR);
    $stmt -> bindParam(':rue',$rue, PDO::PARAM_STR);
    $stmt -> bindParam(':quartier',$quartier, PDO::PARAM_STR);
    $stmt -> bindParam(':id',$id, PDO::PARAM_INT);
    $stmt->execute();





    if ($stmt->error) {

        echo "Echec! " . $stmt->error;
    }else 
        echo "Updated {$stmt->affected_rows} rows";

    return $conn->lastInsertId();


}