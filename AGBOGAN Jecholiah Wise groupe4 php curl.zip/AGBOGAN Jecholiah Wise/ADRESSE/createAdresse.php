<?php

require_once ('database.php');



header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, 
Access-Control-Allow-Methods, Authorization,X-Requested-With');



if (isset($_POST["pays"]) && isset($_POST["ville"]) && isset($_POST["rue"]) && isset($_POST["quartier"])){

    $pays = htmlspecialchars($_POST["pays"]);
    $ville = htmlspecialchars($_POST["ville"]);
    $rue = htmlspecialchars($_POST["rue"]);
    $quartier = htmlspecialchars($_POST["quartier"]);

    global $conn;

    $sql = "INSERT INTO adresse (pays, ville, rue, quartier) VALUES (:pays, :ville, :rue, :quartier)";
    $stmt = $conn->prepare($sql);
    $stmt -> bindParam(':pays',$pays, PDO::PARAM_STR);
    $stmt -> bindParam(':ville',$ville, PDO::PARAM_STR);
    $stmt -> bindParam(':rue',$rue, PDO::PARAM_STR);
    $stmt -> bindParam(':quartier',$quartier, PDO::PARAM_STR);
    $stmt->execute();

    echo "Enregistrement d'adresse reussie";
    $id = $conn->lastInsertId();
    $data= array("id" => "$id");
    $json_data = json_encode($data);

    $url = "http://127.0.0.1/ADRESSE/createClient.php"; 
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
    curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_POSTREDIR, 3);


    $result = curl_exec($curl);

    if($result === false){
        var_dump(curl_error($curl));
    }else{
        var_dump(curl_getinfo($curl, CURLINFO_HTTP_CODE));
    }
    curl_close($curl);

}


?>