<?php 

    require_once ('database.php');


    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');
    header('Access-Control-Allow-Methods: DELETE');
    header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, 
    Content-Type, Access-Control-Allow-Methods, Authorization,X-Requested-With');


    if(isset ($_GET['id'])){

        $id = $_GET['id'];
        try{

            global $conn;

            $sqlDelete = " DELETE FROM adresse WHERE id= '" .$id."' ";
            $conn->exec($sqlDelete);

            echo "Adresse supprimee";  

        }catch(PDOException $e) {

            echo $sql . $e->getMessage();

        }

    }